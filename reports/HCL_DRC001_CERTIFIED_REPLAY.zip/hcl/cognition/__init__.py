"""Opt-in shared cognition workspace; historical v1 entry remains available."""
from .core import Claim, ClaimKind, Dependency, EvidenceCore, Interpretation, Scope, SourceSpan
from .workspace import CognitionWorkspace, OperationResult

__all__ = ['Claim', 'ClaimKind', 'Dependency', 'EvidenceCore', 'Interpretation',
           'Scope', 'SourceSpan', 'CognitionWorkspace', 'OperationResult',
           'ConceptCriteriaWorkspace', 'ConceptCriteriaPreparation',
           'ArgumentWorkspace', 'ArgumentPreparation',
           'ArgumentSensitivityWorkspace', 'SensitivityPreparation',
           'QueryDirectedWorkspace', 'PlannedCognition',
           'DiscriminatingEvidenceWorkspace', 'DiscriminatingPreparation',
           'CognitiveExecutionGraph', 'CognitiveExecution',
           'AnswerAuditWorkspace', 'AuditedAnswer',
           'HardCognitionSession', 'HardCognitionResult',
           'AuthorizedText', 'SemanticResult', 'prepare_semantics', 'PositionAssessment', 'assess_positions', 'RetainedResult', 'prepare_retained', 'answer_retained', 'Attitude', 'MentalProposition', 'EpistemicBundle', 'prepare_epistemic', 'CommunicationScene', 'CommunicationView', 'RevisionTimeline', 'RevisionSnapshot', 'SourceRecord', 'ReportAssessment', 'prepare_reports', 'IntegratedScene', 'IntegratedSceneResult', 'AgencyResult', 'prepare_agency', 'ActionExplanations', 'prepare_explanations', 'PlanFeasibility', 'prepare_plan_feasibility', 'AppraisalResult', 'prepare_appraisal']

from .semantic import AuthorizedText, SemanticResult, prepare_semantics

from .positions import PositionAssessment, assess_positions

from .retained import RetainedResult, prepare_retained, answer_retained

from .epistemic import Attitude, MentalProposition, EpistemicBundle, prepare_epistemic

from .communication import CommunicationScene, CommunicationView

from .revision_time import RevisionTimeline, RevisionSnapshot, SourceRecord

from .report_provenance import ReportAssessment, prepare_reports

from .integrated_scene import IntegratedScene, IntegratedSceneResult

from .agency import AgencyResult, prepare_agency

from .action_explanations import ActionExplanations, prepare_explanations

from .plan_feasibility import PlanFeasibility, prepare_plan_feasibility

from .appraisal import AppraisalResult, prepare_appraisal

from .agency_chain import AgencyChain, SemanticWorkspace, prepare_agency_chain

from .commitments import CommitmentResult, prepare_commitment

from .mutual_understanding import MutualUnderstanding, prepare_mutual_understanding

from .strategic_communication import StrategicCommunication, prepare_strategic_communication

from .misunderstanding import MisunderstandingResult, prepare_misunderstanding

from .joint_plan import JointPlanResult, prepare_joint_plan

from .relationships import RelationshipResult, prepare_relationship
from .relational_conflict import RelationalConflict, prepare_relational_conflict

from .identity_roles import IdentityRoleResult, prepare_identity_roles

from .contextual_values import ContextualValues, prepare_contextual_values

from .relationship_dynamics import RelationshipDynamicsResult, RelationshipDynamicsWorkspace, prepare_relationship_dynamics

from .episodic import EpisodicIndex, EpisodicRetrieval

from .narrative_time import NarrativeEpisode, NarrativeSnapshot, NarrativeTimeline, parse_narrative_episodes

from .evidence_closure import EvidenceClosure, EvidenceClosureIndex

from .character_development import CharacterDevelopmentComparison, compare_character_development

from .long_narrative import NarrativeCorpus, NarrativeReplay, BranchComparison

from .normative_premises import NormativePremiseWorkspace, NormativePreparation

from .responsibility_composition import ResponsibilityCompositionWorkspace, ResponsibilityComposition

from .concept_criteria import ConceptCriteriaWorkspace, ConceptCriteriaPreparation

from .argument_analysis import ArgumentWorkspace, ArgumentPreparation

from .argument_sensitivity import ArgumentSensitivityWorkspace, SensitivityPreparation

from .query_planner import QueryDirectedWorkspace, PlannedCognition

from .discriminating_evidence import DiscriminatingEvidenceWorkspace, DiscriminatingPreparation

from .execution_graph import CognitiveExecutionGraph, CognitiveExecution

from .answer_audit import AnswerAuditWorkspace, AuditedAnswer

from .hard_cognition import HardCognitionSession, HardCognitionResult
